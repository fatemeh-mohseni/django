# import models and serializers
from .serializer import ProjectCreateSerializer , SubprojectCreateSerializer , ProjectViewSerializer , SubprojectViewSerializer , SubprojectUpdateSerializer 
from circular3191.models import Project , Subproject 
from rest_framework import generics, serializers
from ..views import circular3191
from drf_multiple_model.views import ObjectMultipleModelAPIView


subnum = None
projname = None

class SubprojectCreateAPIView (generics.ListCreateAPIView):
    queryset = Subproject.objects.all()

    serializer_class = SubprojectCreateSerializer
    
class ProjectCreateAPIView (generics.ListCreateAPIView):
    queryset = Project.objects.all().values('project_name')
    serializer_class = ProjectCreateSerializer
  

# -------------------------------------------------------------------------

class ProjectListAPIView (generics.ListAPIView):
    queryset = Project.objects.all()
    
    #queryset = Project.objects.filter(project_name = projname)
    serializer_class = ProjectViewSerializer


class SubprojectListAPIView (generics.ListAPIView):

    def __init__(self) :
        circ = circular3191()
    #    print('calstorage',circ[0])
    #    print('finalfinal',circ[1])
    queryset = Subproject.objects.all()
    #queryset = Subproject.objects.filter(project_id = subnum)
    serializer_class = SubprojectViewSerializer



# nested api views 

class TextAPIView(ObjectMultipleModelAPIView):

    querylist = [
        {'queryset': Subproject.objects.all(), 'serializer_class': SubprojectViewSerializer},
    ]


# -------------------------------------------------------------------------
#update api drf

class ProjectUpdateApi(generics.RetrieveUpdateAPIView) :
    queryset = Project.objects.all()
    serializer_class = ProjectCreateSerializer


class SubprojectUpdateApi(generics.RetrieveUpdateAPIView) :
    queryset = Subproject.objects.all()
    serializer_class = SubprojectUpdateSerializer





