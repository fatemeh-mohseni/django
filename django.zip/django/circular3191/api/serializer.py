from django.db import models
from django.db.models import fields
from django.db.models.base import Model
from rest_framework.serializers import ModelSerializer 
from circular3191.models import Project , Subproject 
from rest_framework import serializers

# -------------------------------------------------------------------------
# API for catch data

class SubprojectCreateSerializer (ModelSerializer):
    #project = serializers.CharField()
    class Meta :
        model = Subproject 
        fields = ('project', 'subproject_name' , 'group','repetition','cost_per_meter','area','initial_estimate')


class ProjectCreateSerializer (ModelSerializer):
    class Meta :
        model = Project 
        fields = ('project_name',) 
   
# -------------------------------------------------------------------------
# API for show data


class SubprojectViewSerializer (ModelSerializer) :
    project = serializers.CharField(read_only=True)
    class Meta :
        model = Subproject
        fields = '__all__'
        depth = 1

class ProjectViewSerializer (ModelSerializer) :
    #subproject = SubprojectViewSerializer(read_only = True)
    subprojects = SubprojectViewSerializer(read_only=True, many=True)
    class Meta :
        model = Project 
        #subp = SubprojectViewSerializer().fields
        fields = '__all__'
        #depth = 3

# -------------------------------------------------------------------------


class SubprojectUpdateSerializer (ModelSerializer):
  
    class Meta :
        model = Subproject 
        fields = ('id','project_name',) 
   

