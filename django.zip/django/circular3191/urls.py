from django.urls import path
from . import views

urlpatterns = [
    path('main/', views.circular3191 , name = 'circular3191'),

]   # names should be string