from django.apps import AppConfig


class Circular3191Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'circular3191'
